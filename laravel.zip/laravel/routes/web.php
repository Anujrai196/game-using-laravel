<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|


Route::get('/', function () {
    return view('welcome');
});

Route::get('create','StudentController@create');

Route::view('form','userview');
Route::post('submit','student@save');


Route::get('/',"StudentController@index");
Route::get('/edit/{id}',"StudentController@edit");
Route::get('/show/{id}',"StudentController@show");
Route::get('/create',"StudentController@create");
Route::post('/store',"StudentController@store");
Route::post('/update/{id}',"StudentController@update");
*/


Route::get('/games', 'GamesController@index');
 
Route::get('/games/create', 'GamesController@create');
 
Route::get('/games/{game}', 'GamesController@show');
 
Route::post('/games', 'GamesController@store');
 
Route::post('/games/{game}/reviews', 'ReviewsController@store');

Route::get('/register', 'registrationController@create');
Route::post('/register', 'registrationController@store')->name('register.store');
 
Route::get('/login', 'SessionController@create');
Route::post('/login', 'SessionController@store');
Route::get('/logout', 'SessionController@destroy');


 
use App\game;
 
    $games = App\Game::all();
    
  