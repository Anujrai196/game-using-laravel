
<!DOCTYPE html>
<html lang="en">
<head></head>
<body>
<footer class="footer">
    <div class="container">
        <span class="text-muted">We Like Games</span>
    </div>
</footer>

</body>
</html>