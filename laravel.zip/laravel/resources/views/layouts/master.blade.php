<!DOCTYPE html>
<html lang="en">
 <head>
 @include('layouts.partials.header')
 </head>
 <body>
 
 @include('layouts.partials.navbar')
 <div class="container">
    @yield('content')
</div>

 </body>
</html>


 

 
