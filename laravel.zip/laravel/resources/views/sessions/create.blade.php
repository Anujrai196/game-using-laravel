@extends('layouts.master') 
@section('content')
<h2>Log In</h2>
    
    <form method="POST" action="/login">
        {{ csrf_field() }}
        <div class="form-group">
            <label for="email">Email:</label><br>
            <input type="email" class="form-control" id="email" name="email">
        </div>
 
        <div class="form-group">
            <label for="password">Password:</label><br>
            <input type="password" class="form-control" id="password" name="password">
        </div>
 
        <div class="form-group">
           <br> <button style="cursor:pointer" type="submit" class="btn btn-primary">Login</button>
        </div>
    
    </form>
@endsection