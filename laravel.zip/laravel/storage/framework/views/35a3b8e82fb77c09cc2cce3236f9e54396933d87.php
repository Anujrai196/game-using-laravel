 
<?php $__env->startSection('content'); ?>
 
    <div class="card" style="width: 270px;margin: 5px">
        <img class="card-img-top" src="/<?php echo e($game->title); ?>.png" alt="Card image cap">
        <div class="card-block">
            <h3 class="card-title"><?php echo e($game->title); ?></h3>
            <p class="card-text"><?php echo e($game->title); ?> is published by <?php echo e($game->publisher); ?></p>
            <a href="/games" class="btn btn-primary">List Games</a>
        </div>
    </div>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/games/show.blade.php ENDPATH**/ ?>