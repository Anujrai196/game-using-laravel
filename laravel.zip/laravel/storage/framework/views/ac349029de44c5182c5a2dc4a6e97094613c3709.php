<html>
<body>
    <form action="submit" method ="POST">
    <?php echo csrf_field(); ?>
    Name:    <input type="text" name="name" placeholder="name">
    <br><br>
    Rollno:  <input type="text" name="rollno" placeholder="rollno">
    <br><br>
    Marks:   <input type="text" name="marks" placeholder="marks">
    <br><br>
    Age:     <input type="text" name="age" placeholder="age">
    <br><br>
    <button type="submit">submit</button>
    </form>
</body>
</html>

<?php /**PATH C:\xampp\htdocs\laravel\resources\views/userview.blade.php ENDPATH**/ ?>