<!DOCTYPE html>
<html lang="en">
 <head>
 <?php echo $__env->make('layouts.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 </head>
 <body>
 
 <?php echo $__env->make('layouts.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <div class="container">
    <?php echo $__env->yieldContent('content'); ?>
</div>

 </body>
</html>


 

 
<?php /**PATH C:\xampp\htdocs\laravel\resources\views/layouts/master.blade.php ENDPATH**/ ?>