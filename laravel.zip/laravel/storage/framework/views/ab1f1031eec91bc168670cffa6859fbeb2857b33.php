
<table class="table">
  <thead class="thead-light">
    <tr>
        <th scope="col">CNE</th>
        <th scope="col">Name</th>
        <th scope="col">Rollno</th>
        <th scope="col">Marks</th>
        <th scope="col">Age</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($student->cne); ?></td>
      <td><?php echo e($student->Name); ?></td>
      <td><?php echo e($student->rollno); ?></td>
      <td><?php echo e($student->marks); ?></td>
      <td><?php echo e($student->age); ?></td>
     <td>
        <a href="#" class="btn btn-sm btn-info">Show</a>
        <a href="<?php echo e(url('/edit/'.$student->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
        <a href=" " class="btn btn-sm btn-danger">Delete</a>
      </td> 
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>



<?php /**PATH C:\xampp\htdocs\laravel\resources\views/studentslist.blade.php ENDPATH**/ ?>