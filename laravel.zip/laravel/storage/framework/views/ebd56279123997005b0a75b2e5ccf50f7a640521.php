 
<?php $__env->startSection('content'); ?>
<h2>Log In</h2>
    
    <form method="POST" action="/login">
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
            <label for="email">Email:</label><br>
            <input type="email" class="form-control" id="email" name="email">
        </div>
 
        <div class="form-group">
            <label for="password">Password:</label><br>
            <input type="password" class="form-control" id="password" name="password">
        </div>
 
        <div class="form-group">
           <br> <button style="cursor:pointer" type="submit" class="btn btn-primary">Login</button>
        </div>
    
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/sessions/create.blade.php ENDPATH**/ ?>