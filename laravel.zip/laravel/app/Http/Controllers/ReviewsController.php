<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Game;
use App\Review;
 

class ReviewsController extends Controller
{
    public function store(Game $game)
    {
        $this->validate(request(), [
            'body' => 'required|min:3'
        ]);
        Review::create([
            'body' => request('body'),
            'game_id' => $game->id
        ]);
        $game->addReview(request('body'), auth()->id());
        
        return back();
    }
}
