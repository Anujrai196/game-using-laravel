<?php

namespace App\Http\Controllers;

use App\Game;
use Illuminate\Http\Request;

class GamesController extends Controller
{
    public function index()
    {
        $games = Game::all();
        return view('games.index', ['games' => $games]);
    }
    
    public function show($id)
    {
        $game = Game::find($id);
        return view('games.show', ['game' => $game]);
    }
    
    public function create()
    {
        return view('games.create');
    }
    
    public function store()
    {
        $this->validate(request(), [
            'title' => 'required|unique:games',
            'publisher' => 'required',
            'releasedate' => 'required',
            'image' => 'required',
        ]);
        
        $game = new Game;
        $game->title = request('title');
        $game->publisher = request('publisher');
        $game->releasedate = request('releasedate');
        $game->image = request()->file('image')->store('public/images');
        $game->user_id = auth()->id();
        $game->save();
        
        return redirect('/games');
    }


}
