<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;

class registrationController extends Controller
{
    public function create()
    {
        return view('registration.create');
    }

   
    public function store()
    {
        $this->validate(request(), [
            'name' => 'required|regex:/^[\pL\s\-]+$/u',
            'email' => 'required|unique:users,email',
            'password' => 'required|min:6'

        ]);
        
        $user = User::create(request(['name', 'email', 'password']));
        
        auth()->login($user);
        
        return redirect()->to('/games');
    }
}

